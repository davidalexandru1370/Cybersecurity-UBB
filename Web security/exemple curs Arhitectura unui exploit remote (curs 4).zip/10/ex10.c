#include <stdio.h>

void g() {
  char s[12];
  printf("Adresa lui s este: %p\n", &s);
  gets(s);
}

int main() {
  g();
}
