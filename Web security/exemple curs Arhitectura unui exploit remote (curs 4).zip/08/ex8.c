const char code[]="\xb8\x1d\x00\x00\x00\xcd\x80";

int main() {
  int (*f)();
  f = code;
  f();
}
