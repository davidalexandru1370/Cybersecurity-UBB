#include <stdio.h>

const char code[] = "\xb8\x1d\x00\x00\x00\xcd\x80";

void g() {
  int x;
  *(&x + 2) = code;
}

int main() {
  g();
}
