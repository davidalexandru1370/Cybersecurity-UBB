#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>                               
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main() {
  int c, l;
  struct sockaddr_in server;
  char s[100];
  
  c = socket(AF_INET, SOCK_STREAM, 0);
  if (c < 0) {
    fprintf(stderr, "Eroare la creare socket server.\n");
    exit(1);
  }
  
  memset(&server, 0, sizeof(server));
  server.sin_family = AF_INET;
  server.sin_port = htons(3000);
  server.sin_addr.s_addr = inet_addr("127.0.0.1");
  
  if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
    fprintf(stderr, "Eroare la conectarea la server.\n");
    exit(1);
  }
  
  printf("Dati un sir: ");
  fgets(s, 100, stdin);
  send(c, s, strlen(s) + 1, 0);
  recv(c, &l, sizeof(l), 0);
  l = ntohl(l);
  printf("Lungimea sirului raportata de catre server este: %d\n", l);
  close(c);
}
