#include <stdio.h>

void g() {
  char s[12];
  int *x = s;
  printf("Adresa lui s este: %p\n", &s);
  printf("Adresa lui x este: %p\n", &x);
  printf("Adresa de revenire este: %p\n", x[4]);
  gets(s);
  printf("Noua adresa de revenire este: %p\n", x[4]);
}

int main() {
  g();
}
