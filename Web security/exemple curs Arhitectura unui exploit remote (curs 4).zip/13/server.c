#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>                               
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int c;

void tratare() {
  char s[100];
  int i = 0;
  printf("Adresa lui s: %p\n", s);
  printf("Adresa lui i: %p\n", &i);
  do {
    recv(c, &s[i++], 1, 0);
  }
  while (s[i-1] != 0);
  i--;
  i = htonl(i);
  send(c, &i, sizeof(i), 0);
  close(c);
}

int main() {
  int s, l;
  struct sockaddr_in server, client;
  
  s = socket(AF_INET, SOCK_STREAM, 0);
  if (s < 0) {
    fprintf(stderr, "Eroare la creare socket server.\n");
    exit(1);
  }
  
  memset(&server, 0, sizeof(server));
  server.sin_family = AF_INET;
  server.sin_port = htons(3000);
  server.sin_addr.s_addr = INADDR_ANY;
  
  if (bind(s, (struct sockaddr *) &server, sizeof(server)) < 0) {
    fprintf(stderr, "Eroare la bind. Portul este deja folosit.\n");
    exit(1);
  }
  
  listen(s, 5);
  
  while (1) {
    l = sizeof(client);
    memset(&client, 0, l);
    c = accept(s, (struct sockaddr *) &client, &l);
    printf("S-a conectat un nou client.\n");
    if (fork() == 0) {
      tratare();
      exit(0);
    }
  }
}
