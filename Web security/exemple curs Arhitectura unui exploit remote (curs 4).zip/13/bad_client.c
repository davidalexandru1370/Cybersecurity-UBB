#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>                               
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char shell_code[108];

int main() {
  int c, l;
  struct sockaddr_in server;
  
  c = socket(AF_INET, SOCK_STREAM, 0);
  if (c < 0) {
    fprintf(stderr, "Eroare la creare socket server.\n");
    exit(1);
  }
  
  memset(&server, 0, sizeof(server));
  server.sin_family = AF_INET;
  server.sin_port = htons(3000);
  server.sin_addr.s_addr = inet_addr("127.0.0.1");
  
  if (connect(c, (struct sockaddr *) &server, sizeof(server)) < 0) {
    fprintf(stderr, "Eroare la conectarea la server.\n");
    exit(1);
  }

  read(0, shell_code, 109);
  send(c, shell_code, 109, 0);
  recv(c, &l, sizeof(l), 0);
  l = ntohl(l);
  printf("Lungimea sirului raportata de catre server este: %d\n", l);
  close(c);
}
