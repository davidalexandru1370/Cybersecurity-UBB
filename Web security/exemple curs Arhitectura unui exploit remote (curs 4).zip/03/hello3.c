#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#define FILENAME "message.txt"

int main() {
  int fd;
  #define l 13
  char message[l];

  fd = open(FILENAME, O_RDONLY);
  read(fd, message, l);
  close(fd);
  write(1, message, l);
}
